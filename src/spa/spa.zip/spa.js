import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Button, Card, Modal, Form, Carousel, InputGroup, Tabs, Tab } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './spa.css';
import { FaUser, FaEnvelope, FaLock, FaEye, FaEyeSlash, FaGoogle, FaFacebook } from 'react-icons/fa';
import Swal from 'sweetalert2';
import axios from 'axios';
import AOS from "aos";
import "aos/dist/aos.css";

const SpaBooking = ({ user, setUser, points, setPoints, setAadhar }) => {
  const [selectedGender, setSelectedGender] = useState('Men');
  const [selectedService, setSelectedService] = useState(null);
  const [selectedServices, setSelectedServices] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState(null);
  const [bookedSlots, setBookedSlots] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [paytype, setPaytype] = useState("");
  const [status, setStatus] = useState("");
  const [amount, setAmount] = useState(0);
  const [usedPoints, setUsedPoints] = useState();
  const [booked, setBooked] = useState("booked");
  const [errorMessage, setErrorMessage] = useState("");
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [isNewUser, setIsNewUser] = useState(false);
  const [loading, setLoading] = useState(false);
  const [point, setPoint] = useState();
  const [value, setValue] = useState();
  const [showPassword, setShowPassword] = useState(false);
  const [userData, setUserData] = useState({
    username: "",
    email: "",
    password: ""
  });

  const services = {
    Men: [
      {
        id: 1,
        name: 'Swedish Massage',
        description: 'It is often used to relax you, relieve stress and relieve pain. Swedish massage often involves rubbing, kneading, stroking and tapping your muscles',
        amount: 300,
        imageUrl: 'https://massagenownepa.com/wp-content/uploads/2021/08/Top-10-Benefits-of-Swedish-Massage-Therapy-3.jpeg',
      },
      {
        id: 2,
        name: 'Aromatherapy Massage',
        description: 'Aromatherapy is a specific type of therapy that incorporates scented essential oils into a massage. The massage involves alternating between gentle and harder pressure while using a particular blend of essential oils.',
        amount: 300,
        imageUrl: 'https://mtroyalspa.com/media/main/images/image_3.normal.png',
      },
      {
        id: 3,
        name: 'Thai Massage',
        description: 'Traditional Thai massage combines acupressure, Indian Ayurvedic principles, and assisted yoga postures, but with no use of oils or lotions. The recipient remains clothed during treatment.',
        amount: 300,
        imageUrl: 'https://t4.ftcdn.net/jpg/00/49/84/71/360_F_49847134_GDTYb3FKMNxHDPvZ35OlMPT6G3Wpfkpm.jpg',
      },
    ],
    Women: [
      {
        id: 1,
        name: 'Swedish Massage',
        amount: 300,
        description: 'It is often used to relax you, relieve stress and relieve pain. Swedish massage often involves rubbing, kneading, stroking and tapping your muscles',
        imageUrl: 'https://images.squarespace-cdn.com/content/v1/63a35472a0ab201630426c20/424ec407-ad4d-431d-a1c7-126bea60d868/Head-Massage-FloridaAcademy-1500x1000.jpg',
      },
      {
        id: 2,
        name: 'Aromatherapy Massage',
        description: 'Aromatherapy is a specific type of therapy that incorporates scented essential oils into a massage. The massage involves alternating between gentle and harder pressure while using a particular blend of essential oils.',
        amount: 300,
        imageUrl: 'https://us.123rf.com/450wm/kzenon/kzenon1401/kzenon140100090/25006116-chinese-asian-woman-in-wellness-beauty-spa-having-aroma-therapy-massage-with-essential-oil-looking.jpg?ver=6',
      },
      {
        id: 3,
        name: 'Thai Massage',
        description: 'Traditional Thai massage combines acupressure, Indian Ayurvedic principles, and assisted yoga postures, but with no use of oils or lotions. The recipient remains clothed during treatment.',
        amount: 300,
        imageUrl: 'https://t3.ftcdn.net/jpg/07/81/44/36/360_F_781443695_k9Y2KZgZemjtnTybNPD4gSFP1OLcD90H.jpg',
      },
    ],
  };

  useEffect(() => {
    if (
      !selectedService ||
      !services[selectedGender].some(
        (service) => service.id === selectedService.id
      )
    ) {
      setSelectedService(services[selectedGender][0]);
    }

    AOS.init({ duration: 1500 });
  }, [selectedGender, services]);
  const timeSlots = [
    '9:00 AM',
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '01:00 PM',
    '02:00 PM',
    '03:00 PM',
    '04:00 PM',
    '05:00 PM',
    '06:00 PM',
    '07:00 PM',
  ];
  const isToday = (date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const getAvailableTimeSlots = () => {
    return timeSlots;
  };

  const isTimeSlotDisabled = (slot) => {
    if (!isToday(selectedDate)) {
      return false;
    }

    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();

    const [time, period] = slot.split(' ');
    const [hours, minutes] = time.split(':').map(Number);
    let slotHour = hours;

    if (period === 'PM' && hours !== 12) {
      slotHour += 12;
    } else if (period === 'AM' && hours === 12) {
      slotHour = 0;
    }

    return slotHour < currentHour || (slotHour === currentHour && minutes <= currentMinute);
  };
  const formatDateForInput = (date) => {
    return date.toISOString().split('T')[0];
  };
  const isSlotBooked = (slot) => bookedSlots.includes(slot);
  const handleDateChange = (e) => {
    const newDate = new Date(e.target.value);
    setSelectedDate(newDate);
    setSelectedTime(null); // Reset selected time when date changes
  };
  const handleSelectService = (service) => {
    setSelectedServices((prevSelected) => {
      const alreadySelected = prevSelected.find(s => s.id === service.id);
      if (alreadySelected) {
        return prevSelected.filter(s => s.id !== service.id);
      } else {
        return [...prevSelected, service];
      }
    });
  };

  const handleSelectSlot = (slot) => {
    setSelectedTime(slot);
  };
  const availableSlots = getAvailableTimeSlots();
  const handleScroll = () => {
    const section = document.getElementById("target-section");
    section.scrollIntoView({ behavior: "smooth" });
  };
  //Helper functions
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollDown = () => {
    const section = document.getElementById("datetime-section");
    section.scrollIntoView({ behavior: "smooth" });
  };

  const handleDown = () => {
    const section = document.getElementById("section");
    section.scrollIntoView({ behavior: "smooth" });
  };

  const signUp = async () => {
    if (!userData.username || (isNewUser && !userData.email) || !userData.password) {
      setErrorMessage('All fields are required');
      return;
    }

    setLoading(true);

    const formattedData = {
      name: userData.username,
      email: userData.email,
      password: userData.password,
    };

    try {
      const response = await axios.post(
        "https://7e3081e3a58d.ngrok-free.app/kovais/create-customer/",
        formattedData,
        {
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
          },
        }
      );

      console.log("Signup Success:", response.data);
      localStorage.setItem("signedUpUser", JSON.stringify(formattedData));

      setErrorMessage('');

      setTimeout(() => {
        setIsNewUser(false);
        setLoading(false);

        Swal.fire({
          icon: "success",
          title: "Account Created!",
          text: "Please sign in with your new account",
        });
      }, 1000);

    } catch (error) {
      console.error("Signup Error:", error);

      const errorMsg = error.response?.data?.error ||
        error.response?.data?.message ||
        "Sign-Up Failed. Please try again.";

      setErrorMessage(errorMsg);

      Swal.fire({
        icon: "error",
        title: "Signup Failed",
        text: errorMsg,
      });
    } finally {
      setLoading(false);
    }
  };

  const loginUser = async () => {
    if (!userData.username || !userData.password) {
      setErrorMessage('Username and password are required');
      return;
    }

    setLoading(true);
    setErrorMessage('');

    try {
      const response = await axios.post(
        // "https://api.codingboss.in/kovais/customer-login/",
        "https://7e3081e3a58d.ngrok-free.app/kovais/customer-login/",
        {
          username: userData.username,
          password: userData.password,
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
          },
        }
      );

      console.log("Login Success:", response.data);

      localStorage.setItem("loggedInUser", JSON.stringify(response.data));
      localStorage.setItem("currentUserId", JSON.stringify(response.data.user_id));

      if (response.data.emblem_url || response.data.points) {
        localStorage.setItem("url", JSON.stringify(response.data.emblem_url));
        localStorage.setItem(`points_${response.data.user_id}`, JSON.stringify(response.data.points));
      }

      setUser(response.data);
      setPoints(response.data.points);

      Swal.fire({
        icon: "success",
        title: "Login Successful!",
        timer: 1500,
        showConfirmButton: false
      });

      setTimeout(() => {
        setErrorMessage('');
        setShowLoginModal(false);
        setShowModal(true);
      }, 500);

    } catch (error) {
      console.error("Login Error:", error);

      const errorMsg = error.response?.data?.login ||
        error.response?.data?.message ||
        "Invalid credentials. Please try again.";

      setErrorMessage(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleTabSelect = (key) => {
    setIsNewUser(key === 'signup');
    setErrorMessage('');
  };

  const handleUsePoints = (amount) => {
    const pointsToUse = parseInt(value);
    setUsedPoints(pointsToUse);

    const totalAmount = selectedServices.reduce(
      (total, service) => total + Number(service.amount || 0), 0
    );

    // if (isNaN(pointsToUse) || pointsToUse <= 0) {
    //   alert("Enter a valid number of points.");
    //   return;
    // }

    // if (pointsToUse > points) {
    //   alert(`You only have ${points} points.`);
    //   return;
    // }

    // if (pointsToUse > totalAmount) {
    //   alert(`You can't use more points than the total price. Total is ₹${totalAmount}.`);
    //   return;
    // }

    const newPoints = points - pointsToUse;
    const newPrice = totalAmount - pointsToUse;

    setPoints(newPoints);
    setAmount(newPrice);
    localStorage.setItem("reducedPrice", JSON.stringify(newPrice));

    // alert(`Used ${pointsToUse} points. New total price: ₹${newPrice}, Remaining points: ${newPoints}`);
    setValue("");
  };

  const handlePayment = () => {
    const loggedInUser = localStorage.getItem("loggedInUser");

    if (loggedInUser && selectedServices.length > 0 && selectedTime) {
      const user = JSON.parse(loggedInUser);
      setUser(user);
      setShowLoginModal(false);
      setShowModal(true);
    } else {
      console.log("No user is logged in. Showing login modal.");
      setShowLoginModal(true);
      setShowModal(false);
    }
  };

  async function createPayment() {
    const url = "https://7e3081e3a58d.ngrok-free.app/kovais/create/";
    const id = localStorage.getItem("spaId")

    const payload = {
      amount: amount || selectedServices.reduce((total, service) => total + Number(service.amount || 0), 0),
      order_type: "spa",
      order_id: id,
      gateway: "cashfree",
      fcm_token: "BOfbrXqOrkm7r8T29LWHJx1d7SoAGMG9wcmtfOu7ZoPv1MKhCEUtT6ScZVnmtwJjfO4zAtB2h-F14Y0pr2VdeyM"
    };

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
          // Add Authorization header here if needed
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      console.log("✅ Payment created successfully:", data);
      return data;
    } catch (error) {
      console.error("❌ Error creating payment:", error.message);
    }
  }

  const handleClicked = () => {
    setShowModal(false);
  };

  const handleFreeService = () => {
    spaRequest();
    setShowModal(false);
  };

  const handlePayupi = () => {
    setShowModal(false);
    spaRequest();
    createPayment()
  };

  useEffect(() => {
    if (status && paytype) {
      setTimeout(() => {
        if (paytype === "offline") {
          handleFreeService();
        } else if (paytype === "online") {
          handlePayupi();
        }
      }, 500);
    }
  }, [status, paytype]);

  const spaRequest = async () => {
    const formattedDate = selectedDate.toISOString().split('T')[0];

    const data = {
      category: selectedGender,
      services: selectedServices.map(service => service.name).join(", "),
      amount: amount || selectedServices.reduce((total, service) => total + Number(service.amount || 0), 0),
      date: formattedDate,
      time: selectedTime,
      payment_status: status,
      payment_type: paytype,
      customer_id: user.user_id,
      status: booked,
      customer_name: user.username,
      points: usedPoints
    };

    try {
      const response = await axios.post(
        // "https://api.codingboss.in/kovais/spa/orders/",
        "https://7e3081e3a58d.ngrok-free.app/kovais/spa/orders/",
        data,
        {
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
        }
      );

      console.log("Success:", response.data);
      localStorage.setItem("spaId", JSON.stringify(response.data.order.id));

      // Swal.fire({
      //   title: "success",
      //   icon: "success",
      //   draggable: false
      // });
      // setTimeout(() => {
      //   createPayment()
      // }, 1000)
    } catch (error) {
      console.error("Error:", error.response ? error.response.data : error.message);
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Something went wrong!",
      });
    }
  };

  return (
    <div className="spa-booking-page">
      <Container fluid className="spa-container">

        {/* Booking Header */}
        <section className="booking-header py-5 bg-gradient text-white text-center">
          <Container>
            {/* Floating background elements */}
            <div className="floating-spa-elements">
              <div className="floating-element element-1">🍃</div>
              <div className="floating-element element-2">🌿</div>
              <div className="floating-element element-3">🍀</div>
              <div className="floating-element element-4">🍂</div>
              <div className="floating-element element-5">🍁</div>
              <div className="floating-element element-6">🌸</div>
              <div className="floating-element element-7">🌺</div>
              <div className="floating-element element-8">🌹</div>
              <div className="floating-element element-9">🌷</div>
              <div className="floating-element element-10">🕯️</div>
              <div className="floating-element element-11">🕯️</div>
              <div className="floating-element element-12">🌼</div>
              <div className="floating-element element-13">💧</div>
              <div className="floating-element element-14">✨</div>
              <div className="floating-element element-15">💫</div>
              <div className="floating-element element-17">💮</div>
              <div className="floating-element element-16">🏵️</div>
              <div className="floating-element element-18">💎</div>
              <div className="floating-element element-19">🕊️</div>


            </div>
            <div data-aos="fade-up">
              <h1 className="display-3 fw-bold mb-3" style={{ fontFamily: "'Playfair Display', serif", color: "#d11f31" }}>Book Your Perfect Session</h1>
              <p className="lead" style={{ color: "black" }}>Choose your preferred services, date, and time for the ultimate spa experience</p>
            </div>
          </Container>
        </section>


        {/* Carousel Section */}
        <section className="carousel-section">
          <Carousel interval={3000} pause={false} controls={true} indicators={true}>
            <Carousel.Item>
              <img
                className="carousel-img"
                src="https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg"
                alt="Spa Treatment"
                style={{ height: 400, width: '100%', objectFit: 'cover' }}
              />
              <Carousel.Caption className="carousel-caption-custom">
                <h3>Relax & Rejuvenate</h3>
                <p>Experience our signature massage therapies</p>
              </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
              <img
                className="carousel-img"
                src="https://www.midastouchfamilyspa.in/wp-content/uploads/2024/09/massage-spa-in-tardeo-marine-drive-mumbai-central.jpg"
                alt="Spa Ambiance"
                style={{ height: 400, width: '100%', objectFit: 'cover' }}
              />
              <Carousel.Caption className="carousel-caption-custom">
                <h3>Tranquil Environment</h3>
                <p>Immerse yourself in our peaceful spa atmosphere</p>
              </Carousel.Caption>
            </Carousel.Item>
          </Carousel>
        </section>

        {/* Gender Selection */}
        <section className="gender-selection-section">
          <Container>
            <div className="section-header" data-aos="fade-up">
              <h2>Select Your Preference</h2>
              <p>Choose your preferred treatment category for a personalized spa experience</p>
            </div>
            <Row className="text-center justify-content-center">
              {[
                {
                  gender: "Men",
                  image: "https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg",
                  description: "Specialized treatments for men"
                },
                {
                  gender: "Women",
                  image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg",
                  description: "Customized wellness for women"
                }
              ].map(({ gender, image, description }, index) => (
                <Col key={index} xs={12} sm={6} md={5} lg={4} className="mb-4">
                  <Card
                    data-aos="fade-up"
                    data-aos-delay={index * 100}
                    onClick={() => {
                      setSelectedGender(gender);
                      handleScroll();
                    }}
                    className={`gender-selection-card h-100 ${selectedGender === gender ? 'selected' : ''}`}
                  >
                    <div className="gender-image-container">
                      <Card.Img
                        variant="top"
                        src={image}
                        alt={gender}
                        className="gender-image"
                      />
                      <div className="gender-overlay">
                        <h4 className="text-white">{gender}</h4>
                        <p className="text-white-50">{description}</p>
                      </div>
                    </div>
                    <Card.Body className="text-center p-3">
                      <Button
                        variant={selectedGender === gender ? "success" : "outline-success"}
                        className="w-100 py-2"
                      >
                        Select {gender}
                      </Button>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          </Container>
        </section>

        {/* Service Selection */}
        <section className="service-selection-section" id="target-section">
          <Container>
            <div className="section-header" data-aos="fade-up">
              <h2>Choose Your Services</h2>
              <p>Select multiple services for your perfect spa experience</p>
            </div>
            <Row>
              {services[selectedGender].map((service, index) => (
                <Col md={4} key={service.id} className="mb-4">
                  <Card
                    data-aos="fade-up"
                    data-aos-delay={index * 100}
                    className={`service-selection-card h-100 ${selectedServices.find(selectedService => selectedService?.id === service.id) ? 'selected' : ''
                      }`}
                    onClick={() => {
                      handleSelectService(service);
                    }}
                  >
                    <div className="service-image-container">
                      <Card.Img variant="top" src={service.imageUrl} className="service-image" />
                      <div className="service-price-badge">₹{service.amount}</div>
                      <div className="service-description-overlay">
                        <p className="text-white small">{service.description}</p>
                      </div>
                    </div>
                    <Card.Body className="p-4">
                      <Card.Title className="h5 text-success">{service.name}</Card.Title>
                      <div className="d-flex justify-content-between align-items-center">
                        <span className="text-muted">Duration: 60 min</span>
                        <div className="service-checkbox">
                          {selectedServices.find(s => s.id === service.id) ? '✓' : '+'}
                        </div>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>

            {selectedServices.length > 0 && (
              <div className="text-center mt-4" data-aos="fade-up">
                <Button
                  variant="success"
                  size="lg"
                  onClick={handleScrollDown}
                  className="px-5 py-3"
                >
                  Continue to Date & Time ({selectedServices.length} service{selectedServices.length > 1 ? 's' : ''} selected)
                </Button>
              </div>
            )}
          </Container>
        </section>

        {/* Date and Time Selection */}
        <section id="datetime-section" className="datetime-section">
          <div className="container">
            <div className="section-header">
              <h2 className="section-title">Select Date & Time</h2>
              <p className="section-description">
                Choose your preferred appointment date and available time slot
              </p>
            </div>

            <div className="datetime-container">
              <div className="datetime-grid">
                {/* Date Selection */}
                <div className="date-selection">
                  <h3 className="datetime-subtitle">Select Date</h3>
                  <div className="date-input-container">
                    <input
                      type="date"
                      value={formatDateForInput(selectedDate)}
                      onChange={handleDateChange}
                      min={formatDateForInput(new Date())}
                      className="date-input"
                    />
                    <div className="selected-date-display">
                      <p className="selected-date-text">
                        Selected: {selectedDate.toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Time Selection */}
                <div className="time-selection">
                  <h3 className="datetime-subtitle">Available Times</h3>
                  <div className="time-slots-grid">
                    {availableSlots.map((slot) => {
                      const isDisabled = isTimeSlotDisabled(slot);
                      return (
                        <button
                          key={slot}
                          onClick={() => !isDisabled && setSelectedTime(slot)}
                          disabled={isDisabled}
                          className={`time-slot ${selectedTime === slot ? 'selected' : ''
                            } ${isDisabled ? 'disabled' : ''}`}
                        >
                          {slot}
                        </button>
                      );
                    })}
                  </div>

                  {isToday(selectedDate) && (
                    <div className="time-warning">
                      <p className="time-warning-text">
                        Past time slots are disabled for today's date.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {selectedTime && selectedServices.length > 0 && (
              <div className="booking-summary-container">

                <div className="payment-continue">
                  <button
                    onClick={handlePayment}
                    className="payment-btn"
                  >
                    Proceed to Payment
                  </button>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Payment Modal */}
        <Modal show={showModal} onHide={handleClicked} centered size="lg" >
          <Modal.Header closeButton className="border-0 pb-0">
            <Modal.Title className="text-success">Complete Your Booking</Modal.Title>
          </Modal.Header>
          <Modal.Body className="p-4">
            <div className="payment-banner mb-4">
              <img
                src="https://www.arzttermine.de/magazin/wp-content/uploads/Aromatheraphie-1.png"
                alt="Spa Banner"
                className="img-fluid rounded"
              />
            </div>

            {selectedServices.length > 0 && (
              <div className="booking-details mb-4 p-3 bg-light rounded">
                <h5 className="text-success mb-3">Booking Details</h5>
                <div className="services-list">
                  {selectedServices.map(service => (
                    <div key={service.id} className="d-flex justify-content-between py-2 border-bottom">
                      <span>{service.name}</span>
                      <span className="fw-bold">₹{service.amount}</span>
                    </div>
                  ))}
                </div>
                <div className="total-amount mt-3 pt-3 border-top">
                  <div className="d-flex justify-content-between">
                    <span className="h5">Total Amount:</span>
                    <span className="h5 text-success fw-bold">
                      ₹{amount || selectedServices.reduce((total, s) => total + s.amount, 0)}
                    </span>
                  </div>
                </div>
                <div className="booking-info mt-3">
                  <p className="mb-1"><strong>Date:</strong> {selectedDate.toLocaleDateString()}</p>
                  <p className="mb-0"><strong>Time:</strong> {selectedTime}</p>
                </div>
              </div>
            )}

            <div className="points-section p-3 bg-light rounded">
              <h6 className="text-success mb-3">Use Your Reward Points</h6>
              <Row className="align-items-end">
                <Col>
                  <Form.Label className="small text-muted">Available Points: {points || 0}</Form.Label>
                  <Form.Control
                    type="number"
                    placeholder="Enter points to use"
                    value={value || ''}
                    onChange={(e) => setValue(e.target.value)}
                    max={points}
                  />
                </Col>
                <Col xs="auto">
                  <Button
                    variant="outline-success"
                    onClick={() => handleUsePoints(value, amount)}
                    disabled={!value || value <= 0}
                  >
                    Apply Points
                  </Button>
                </Col>
              </Row>
            </div>

            <div className="payment-options">
              <Row className="mb-3">
                <Col>
                  <Button
                    variant="outline-success"
                    className="w-100 py-3"
                    onClick={() => {
                      setStatus("pending");
                      setPaytype("offline");
                    }}
                  >
                    💳 Pay at Spa
                  </Button>
                </Col>
                <Col>
                  <Button
                    variant="success"
                    className="w-100 py-3"
                    onClick={() => {
                      setStatus("completed");
                      setPaytype("online");
                      // Example UPI deep link
                      const upiLink = `upi://pay?pa=merchant@upi&pn=Your%20Merchant%20Name&mc=1234&tid=TXN123456&tr=ORDER123&tn=Service%20Payment&am=100&cu=INR`;

                      // Redirect to UPI app
                      window.location.href = upiLink;
                    }}
                  >
                    📱 Pay with UPI
                  </Button>
                </Col>
              </Row>


            </div>
          </Modal.Body>
        </Modal>

        {/* Login Modal */}
        <Modal
          show={showLoginModal}
          onHide={() => setShowLoginModal(false)}
          centered
        // className="auth-modal"
        >
          <Modal.Header closeButton className="border-0 pb-0">
            <Modal.Title className="w-100 text-center">Welcome</Modal.Title>
          </Modal.Header>
          <Modal.Body className="px-4 pt-0">
            <Tabs
              activeKey={isNewUser ? 'signup' : 'login'}
              onSelect={handleTabSelect}
              className="mb-4 nav-fill"
            >
              <Tab eventKey="login" title="Login" />
              <Tab eventKey="signup" title="Sign Up" />
            </Tabs>

            {/* Form Fields */}
            <Form>
              {/* Username Field */}
              <Form.Group className="mb-3">
                <InputGroup>
                  <InputGroup.Text className="bg-light">
                    <FaUser className="text-secondary" />
                  </InputGroup.Text>
                  <Form.Control
                    type="text"
                    value={userData.username || ""}
                    onChange={(e) => setUserData({ ...userData, username: e.target.value })}
                    placeholder="Username"
                    className="border-start-0"
                  />
                </InputGroup>
              </Form.Group>

              {/* Email Field (Only for Signup) */}
              {isNewUser && (
                <Form.Group className="mb-3">
                  <InputGroup>
                    <InputGroup.Text className="bg-light">
                      <FaEnvelope className="text-secondary" />
                    </InputGroup.Text>
                    <Form.Control
                      type="email"
                      value={userData.email || ""}
                      onChange={(e) => setUserData({ ...userData, email: e.target.value })}
                      placeholder="Email address"
                      className="border-start-0"
                    />
                  </InputGroup>
                </Form.Group>
              )}

              {/* Password Field */}
              <Form.Group className="mb-3">
                <InputGroup>
                  <InputGroup.Text className="bg-light">
                    <FaLock className="text-secondary" />
                  </InputGroup.Text>
                  <Form.Control
                    type={showPassword ? "text" : "password"}
                    value={userData.password || ""}
                    onChange={(e) => setUserData({ ...userData, password: e.target.value })}
                    placeholder="Password"
                    className="border-start-0 border-end-0"
                  />
                  <InputGroup.Text
                    className="bg-light cursor-pointer"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ?
                      <FaEyeSlash className="text-secondary" /> :
                      <FaEye className="text-secondary" />
                    }
                  </InputGroup.Text>
                </InputGroup>
              </Form.Group>

              {/* Forgot Password Link */}
              {!isNewUser && (
                <div className="d-flex justify-content-end mb-3">
                  <Button variant="link" className="p-0 text-decoration-none" size="sm">
                    Forgot password?
                  </Button>
                </div>
              )}

              {/* Error Message */}
              {errorMessage && (
                <div className="alert alert-danger py-2" role="alert">
                  {errorMessage}
                </div>
              )}

              {/* Main Action Button */}
              <Button
                variant="primary"
                onClick={isNewUser ? signUp : loginUser}
                disabled={loading}
                className="w-100 py-2 mt-2 mb-3"
              >
                {loading ?
                  <span>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    {isNewUser ? "Creating Account..." : "Logging in..."}
                  </span> :
                  isNewUser ? "Create Account" : "Login"
                }
              </Button>

              {/* Social Login Options */}
              <div className="text-center mb-3">
                <p className="text-muted position-relative my-3">
                  <span className="bg-white px-2 position-relative" style={{ zIndex: 1 }}>
                    Or continue with
                  </span>
                  <hr className="position-absolute top-50 start-0 end-0 m-0" style={{ zIndex: 0 }} />
                </p>
                <div className="d-flex justify-content-center gap-3">
                  <Button variant="outline-secondary" className="rounded-circle p-2">
                    <FaGoogle />
                  </Button>
                  <Button variant="outline-secondary" className="rounded-circle p-2">
                    <FaFacebook />
                  </Button>
                </div>
              </div>

              {/* Terms & Privacy */}
              {isNewUser && (
                <p className="text-muted text-center small mt-4">
                  By signing up, you agree to our <a href="#" className="text-decoration-none">Terms of Service</a> and <a href="#" className="text-decoration-none">Privacy Policy</a>.
                </p>
              )}
            </Form>
          </Modal.Body>
        </Modal>
      </Container>
      <footer className="footer">
        <p>&copy; 2024 KOVAIS. All Rights Reserved. | Contact: 9234567891 | Email: info@kovaisbeauty.com</p>
      </footer>
    </div>
  );
};

export default SpaBooking;