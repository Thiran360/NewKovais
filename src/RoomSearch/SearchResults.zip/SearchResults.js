import React, { useState, useEffect, useRef } from 'react';
import {
  Heart,
  MapPin,
  Calendar,
  Users,
  Star,
  Camera,
  Share2,
  Filter,
  SortAsc,
  Eye,
  Clock,
  Shield,
  Award,
  MessageCircle,
  Phone,
  Mail,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  ThumbsUp,
  ThumbsDown,
  Bookmark,
  Navigation,
  Sun,
  Moon,
  Sparkles,
  Zap,
  ChevronLeft,
  ChevronRight,
  ChevronDown,

  ChevronUp
} from 'lucide-react';
import Swal from "sweetalert2";
import { format, set } from 'date-fns';
import { Row, Col, Modal, Button, Spinner, Tabs, Tab, Form, InputGroup } from 'react-bootstrap';
import { FaUser, FaEnvelope, FaLock, FaEye, FaEyeSlash, FaGoogle, FaFacebook, FaDumbbell, FaUsers, FaClock, FaAward, FaTrophy, FaFire } from 'react-icons/fa';
import axios from "axios";
import "./SearchResults.css";
// Calendar Component
const DateCalendar = ({ isOpen, onClose, onDateSelect, selectedDate, position }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  if (!isOpen) return null;

  const today = new Date();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();

  const handleDateClick = (day) => {
    const newDate = new Date(currentYear, currentMonth, day);
    const formattedDate = newDate.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    onDateSelect(formattedDate);
    onClose();
  };

  const navigateMonth = (direction) => {
    if (direction === 'prev') {
      if (currentMonth === 0) {
        setCurrentMonth(11);
        setCurrentYear(currentYear - 1);
      } else {
        setCurrentMonth(currentMonth - 1);
      }
    } else {
      if (currentMonth === 11) {
        setCurrentMonth(0);
        setCurrentYear(currentYear + 1);
      } else {
        setCurrentMonth(currentMonth + 1);
      }
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0,0,0,0.3)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          backgroundColor: '#fff',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 8px 32px rgba(0,0,0,0.15)',
          minWidth: '320px',
          border: '1px solid #e1e5e9'
        }}
      >
        {/* Calendar Header */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '20px'
        }}>
          <button
            onClick={() => navigateMonth('prev')}
            style={{
              backgroundColor: 'transparent',
              border: '1px solid #e1e5e9',
              borderRadius: '6px',
              padding: '8px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center'
            }}
          >
            <ChevronLeft size={16} />
          </button>
          <h4 style={{
            margin: '0',
            fontSize: '18px',
            fontWeight: '600',
            color: '#333'
          }}>
            {monthNames[currentMonth]} {currentYear}
          </h4>
          <button
            onClick={() => navigateMonth('next')}
            style={{
              backgroundColor: 'transparent',
              border: '1px solid #e1e5e9',
              borderRadius: '6px',
              padding: '8px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center'
            }}
          >
            <ChevronRight size={16} />
          </button>
        </div>

        {/* Days of Week */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(7, 1fr)',
          gap: '4px',
          marginBottom: '8px'
        }}>
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div
              key={day}
              style={{
                textAlign: 'center',
                fontSize: '12px',
                fontWeight: '600',
                color: '#6c757d',
                padding: '8px 0'
              }}
            >
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(7, 1fr)',
          gap: '4px'
        }}>
          {/* Empty cells for days before month starts */}
          {[...Array(firstDayOfMonth)].map((_, index) => (
            <div key={`empty-${index}`} style={{ height: '40px' }} />
          ))}

          {/* Calendar days */}
          {[...Array(daysInMonth)].map((_, index) => {
            const day = index + 1;
            const dateToCheck = new Date(currentYear, currentMonth, day);
            const isToday = today.getDate() === day && today.getMonth() === currentMonth && today.getFullYear() === currentYear;
            const isPastDate = dateToCheck < today && !isToday;

            return (
              <button
                key={day}
                onClick={() => handleDateClick(day)}
                disabled={isPastDate}
                style={{
                  height: '40px',
                  backgroundColor: isToday ? '#dc3545' : 'transparent',
                  color: isToday ? 'white' : (isPastDate ? '#bbb' : '#333'),
                  border: '1px solid #e1e5e9',
                  borderRadius: '6px',
                  cursor: isPastDate ? 'not-allowed' : 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                  transition: 'all 0.2s ease',
                  opacity: isPastDate ? 0.5 : 1,
                }}
                onMouseEnter={(e) => {
                  if (!isToday && !isPastDate) {
                    e.target.style.backgroundColor = '#f8f9fa';
                    e.target.style.borderColor = '#dc3545';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isToday && !isPastDate) {
                    e.target.style.backgroundColor = 'transparent';
                    e.target.style.borderColor = '#e1e5e9';
                  }
                }}
              >
                {day}
              </button>
            );
          })}
        </div>

        {/* Calendar Footer */}
        <div style={{
          marginTop: '20px',
          paddingTop: '16px',
          borderTop: '1px solid #e1e5e9',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <span style={{ fontSize: '12px', color: '#6c757d' }}>
            Select your preferred date
          </span>
          <button
            onClick={onClose}
            style={{
              backgroundColor: '#dc3545',
              color: 'white',
              border: 'none',
              padding: '6px 12px',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '12px',
              fontWeight: '600'
            }}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

const SearchResults = ({ user, setUser, setAadhar, aadhar, setPoints, points }) => {
  // State Management
  const [selectedRoomType, setSelectedRoomType] = useState("Deluxe Suite");
  const [position, setPosition] = useState('checkIn');
  const [roomCounts, setRoomCounts] = useState([1]);
  const [guestCounts, setGuestCounts] = useState([2]);
  const [showModal, setShowModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showVirtualTour, setShowVirtualTour] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [checkIn, setCheckIn] = useState(new Date());
  const [checkOut, setCheckOut] = useState(new Date(Date.now() + 86400000));
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [status, setStatus] = useState("");
  const [paytype, setPaytype] = useState("");
  const [usedPoints, setUsedPoints] = useState("")
  const [showPassword, setShowPassword] = useState(false);
  const [booked, setBooked] = useState("booked")
  const [aadharFile, setAadharFile] = useState(null);
  const [availableRooms, setAvailableRooms] = useState(10); // Fetched from API
  const [totalAmount, setTotalAmount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [isNewUser, setIsNewUser] = useState(false);
  const [value, setValue] = useState(""); // For points input
  const [purposeOfVisit, setPurposeOfVisit] = useState("");
  const [userData, setUserData] = useState({ username: "", phone_number: "", password: "" });

  // Form fields state
  const [location, setLocation] = useState("Gobichettipalayam, Erode India");
  const [checkInDate, setCheckInDate] = useState("");
  const [checkOutDate, setCheckOutDate] = useState("");
  const [roomType, setRoomType] = useState("Delux Room");
  const checkOutRef = useRef();
  const checkInRef = useRef();
  const [checkInOpen, setCheckInOpen] = useState(false);

  // Calendar state
  const [showCheckInCalendar, setShowCheckInCalendar] = useState(false);
  const [showCheckOutCalendar, setShowCheckOutCalendar] = useState(false);

  // Features State
  const [sortBy, setSortBy] = useState('price');
  const [filterBy, setFilterBy] = useState('all');
  const [savedRooms, setSavedRooms] = useState(new Set());
  const [total, setRoom] = useState("")
  const [currentImageIndex, setCurrentImageIndex] = useState({});
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [weatherData, setWeatherData] = useState(null);
  const [nearbyAttractions, setNearbyAttractions] = useState([]);
  const [realTimeOccupancy, setRealTimeOccupancy] = useState({});
  const [virtualTourProgress, setVirtualTourProgress] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentReview, setCurrentReview] = useState(0);

  // Special Request State
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState({
    earlyCheckIn: { checked: false, time: "" },
    lateCheckOut: { checked: false, time: "" },
    extraBed: { checked: false, count: 0 },
  });
  // Request Options
  const requestOptions = [
    { id: 'earlyCheckIn', label: 'Early check-in', showTime: true, showInput: false },
    { id: 'lateCheckOut', label: 'Late check-out', showTime: true, showInput: false },
    { id: 'extraBed', label: 'Extra bed', showTime: false, showInput: true },
    // { id: 'quietRoom', label: 'Quiet room', showTime: false, showInput: false },
    // { id: 'highFloor', label: 'High floor', showTime: false, showInput: false },
    // { id: 'adjoiningRooms', label: 'Adjoining rooms', showTime: false, showInput: false },
    // { id: 'airportTransfer', label: 'Airport transfer', showTime: true, showInput: false },
    // { id: 'wheelchairAccess', label: 'Wheelchair accessible room', showTime: false, showInput: false }
  ];

  // Enhanced Room Data
  const rooms = [
    {
      id: 1,
      type: 'Deluxe Suite',
      title: 'Premium Deluxe Suite with City View',
      description: 'Experience luxury with panoramic city views, smart home automation, and premium amenities.',
      price: 4500,
      originalPrice: 6000,
      taxes: 788,
      rating: 4.8,
      reviewCount: 342,
      location: 'Gobichettypalayam Premium District',
      images: [
        'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg',
        'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg',
        'https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg',
        'https://images.pexels.com/photos/2029667/pexels-photo-2029667.jpeg'
      ],
      amenities: [
        { name: 'Smart TV', icon: '📺', available: true },
        { name: 'High-Speed WiFi', icon: '📶', available: true },
        { name: 'Mini Bar', icon: '🍷', available: true },
        { name: 'Room Service', icon: '🛎️', available: true },
        { name: 'Balcony', icon: '🏙️', available: true },
        { name: 'Air Conditioning', icon: '❄️', available: true }
      ],
      features: {
        smartHome: true,
        voiceControl: true,
        moodLighting: true,
        premiumBedding: true,
        cityView: true,
        soundproofing: true
      },
      virtualTour: 'https://example.com/virtual-tour-1',
      ecoRating: 4.2,
      carbonFootprint: 'Low',
      lastBooked: '2 hours ago',
      popularityScore: 95,
      instantConfirmation: true,
      freeCancellation: true,
      cancellationDeadline: '24 hours',
      specialOffers: ['Early Bird 20% Off', 'Extended Stay Discount'],
      nearbyAttractions: ['City Mall - 0.5km', 'Central Park - 1.2km', 'Museum - 2.1km']
    }
  ];

  // Weather Info
  const weatherInfo = {
    temperature: '24°C',
    condition: 'Sunny',
    humidity: '65%',
    windSpeed: '12 km/h'
  };

  const attractions = [
    { name: 'Ancient Temple', distance: '0.8km', rating: 4.7, type: 'Historical' },
    { name: 'Shopping Complex', distance: '1.2km', rating: 4.5, type: 'Shopping' },
    { name: 'Nature Park', distance: '2.1km', rating: 4.9, type: 'Nature' },
    { name: 'Local Market', distance: '0.5km', rating: 4.3, type: 'Culture' }
  ];

  useEffect(() => {
    // Calculate initial total for first room
    setTotalAmount(roomCounts[0] * rooms[0].price);

    // Simulate real-time data updates
    const interval = setInterval(() => {
      setRealTimeOccupancy(prev => ({
        ...prev,
        [Math.floor(Math.random() * 3) + 1]: Math.floor(Math.random() * 100)
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Special Request Functions
  const toggleAccordion = () => {
    setIsExpanded(!isExpanded);
  };

  const handleCheckboxChange = (id) => {
    setSelectedOptions((prev) => ({
      ...prev,
      [id]: { ...prev[id], checked: !prev[id].checked },
    }));
  };

  const handleTimeChange = (id, value) => {
    setSelectedOptions((prev) => ({
      ...prev,
      [id]: { ...prev[id], time: value },
    }));
  };

  const handleCountChange = (id, value) => {
    setSelectedOptions((prev) => ({
      ...prev,
      [id]: { ...prev[id], count: Number(value) },
    }));
  };



  // Calendar Functions
  const handleCheckInClick = () => {
    setShowCheckInCalendar(true);
    setShowCheckOutCalendar(false);
  };

  const handleCheckOutClick = () => {
    setShowCheckOutCalendar(true);
    setShowCheckInCalendar(false);
  };

  const handleCheckInDateSelect = (date) => {
    if (!date) {
      console.error("Invalid check-in date:", date);
      return;
    }

    // Ensure date is always a Date object
    const checkIn = new Date(date);

    if (isNaN(checkIn.getTime())) {
      console.error("Invalid date format:", date);
      return;
    }

    setCheckInDate(checkIn);

    // Auto-set checkout = next day
    const nextDay = new Date(checkIn.getTime() + 24 * 60 * 60 * 1000);
    setCheckOutDate(nextDay);

    setShowCheckInCalendar(false);
    setShowCheckOutCalendar(true);
  };


  const handleCheckOutDateSelect = (date) => {
    setCheckOutDate(date);
    setShowCheckOutCalendar(false);
  };

  const incrementRoom = (index) => {
    if (index !== 0) return; // Only first room allowed

    const updatedCounts = [...roomCounts];
    if (updatedCounts[index] < availableRooms) {  // limit by availableRooms
      updatedCounts[index] += 1;
      setRoomCounts(updatedCounts);
      setTotalAmount(updatedCounts[0] * rooms[0].price);
    }
  };

  const decrementRoom = (index) => {
    if (index !== 0) return;

    const updatedCounts = [...roomCounts];
    if (updatedCounts[index] > 1) {
      updatedCounts[index] -= 1;
      setRoomCounts(updatedCounts);
      setTotalAmount(updatedCounts[0] * rooms[0].price);
    }
  };

  const incrementGuest = (index) => {
    if (index !== 0) return;

    const updatedGuests = [...guestCounts];
    const maxGuests = roomCounts[index] * 3;
    if (updatedGuests[index] < maxGuests) {
      updatedGuests[index] += 1;
      setGuestCounts(updatedGuests);
    }
  };

  const decrementGuest = (index) => {
    if (index !== 0) return;

    const updatedGuests = [...guestCounts];
    if (updatedGuests[index] > 1) {
      updatedGuests[index] -= 1;
      setGuestCounts(updatedGuests);
    }
  };


  // Features Functions
  const toggleSaveRoom = (roomId) => {
    const newSavedRooms = new Set(savedRooms);
    if (newSavedRooms.has(roomId)) {
      newSavedRooms.delete(roomId);
    } else {
      newSavedRooms.add(roomId);
    }
    setSavedRooms(newSavedRooms);
  };

  const shareRoom = async (room) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: room.title,
          text: room.description,
          url: window.location.href
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Room link copied to clipboard');
    }
  };

  const handleVirtualTour = (room) => {
    setSelectedRoom(room);
    setShowVirtualTour(true);
    setVirtualTourProgress(0);

    // Simulate virtual tour progress
    const progressInterval = setInterval(() => {
      setVirtualTourProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 100);
  };

  const handleBooking = (room, index) => {
    if (!user) {
      setShowLoginModal(true);
      return;
    }

    const roomPrice = room.price;
    const totalBookingAmount = index === 0 ? roomCounts[index] * roomPrice : roomPrice;

    setSelectedRoom({
      ...room,
      roomCount: index === 0 ? roomCounts[index] : 1,
      guestCount: index === 0 ? guestCounts[index] : 2,
      totalAmount: totalBookingAmount,
    });

    setShowModal(true);
  };

  const loginUser = async () => {
    if (!userData.username || !userData.password) {
      setErrorMessage('Username and password are required');
      return;
    }

    setLoading(true);
    setErrorMessage('');

    try {
      const response = await axios.post(
        // "https://api.codingboss.in/kovais/customer-login/",
        "http://192.168.1.57:8000/kovais/customer-login/",
        {
          username: userData.username,
          password: userData.password,
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
          },
        }
      );

      console.log("Login Success:", response.data);

      localStorage.setItem("loggedInUser", JSON.stringify(response.data));
      localStorage.setItem("currentUserId", JSON.stringify(response.data.user_id));

      if (response.data.emblem_url || response.data.points) {
        localStorage.setItem("url", JSON.stringify(response.data.emblem_url));
        localStorage.setItem(`points_${response.data.user_id}`, JSON.stringify(response.data.points))
      }

      setUser(response.data);
      setPoints(response.data.points);

      Swal.fire({
        icon: "success",
        title: "Login Successful!",
        timer: 1500,
        showConfirmButton: false
      });

      setTimeout(() => {
        setErrorMessage('');
        setShowLoginModal(false);
        setShowModal(true);
      }, 500);

    } catch (error) {
      console.error("Login Error:", error);

      const errorMsg = error.response?.data?.login ||
        error.response?.data?.message ||
        "Invalid credentials. Please try again.";

      setErrorMessage(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const signup = async () => {
    if (!userData.username || !userData.phone_number || !userData.password) {
      setErrorMessage('All fields are required');
      return;
    }

    setLoading(true);

    const formattedData = {
      name: userData.username,
      phone_number: userData.phone_number,
      password: userData.password,
    };

    try {
      const response = await axios.post(
        // "https://api.codingboss.in/kovais/create-customer/",
        "http://192.168.1.57:8000/kovais/create-customer/",
        formattedData,
        {
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
          },
        }
      );

      console.log("Signup Success:", response.data);
      localStorage.setItem("signedUpUser", JSON.stringify(formattedData));

      setErrorMessage('');

      setTimeout(() => {
        setIsNewUser(false);
        setLoading(false);

        Swal.fire({
          icon: "success",
          title: "Account Created!",
          text: "Please sign in with your new account",
        });
      }, 1000);

    } catch (error) {
      console.error("Signup Error:", error);

      const errorMsg = error.response?.data?.error ||
        error.response?.data?.message ||
        "Sign-Up Failed. Please try again.";

      setErrorMessage(errorMsg);

      Swal.fire({
        icon: "error",
        title: "Signup Failed",
        text: errorMsg,
      });
    } finally {
      setLoading(false);
    }
  };


  async function createPayment() {
    const url = "http://192.168.1.57:8000/kovais/createe/";
    const id = localStorage.getItem("hotelId");

    const payload = {
      amount: Math.round((totalAmount || selectedRoom.totalAmount) / selectedRoom.roomCount),
      order_type: "hotel",
      order_id: id,
      gateway: "cashfree",
      fcm_token: "BOfbrXqOrkm7r8T29LWHJx1d7SoAGMG9wcmtfOu7ZoPv1MKhCEUtT6ScZVnmtwJjfO4zAtB2h-F14Y0pr2VdeyM"
    };

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
          // Add Authorization header here if needed
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      console.log("✅ Payment created successfully:", data);
      const upiLink = data.upi_link;
      // Redirect to UPI app
      window.location.href = upiLink;
      return data;
    } catch (error) {
      console.error("❌ Error creating payment:", error.message);
    }
  }

  const verify = (room, index) => {
    const loggedInUser = localStorage.getItem("loggedInUser");

    if (loggedInUser) {
      const user = JSON.parse(loggedInUser);
      setUser(user);
      handleShowModal(room, index)
      setShowLoginModal(false);
      setShowModal(true); // ✅ Show payment modal
    } else {
      console.log("No user is logged in. Showing login modal.");
      setShowLoginModal(true);
      setShowModal(false);
    }
  };

  // Handle tab switching
  const handleTabSelect = (key) => {
    setIsNewUser(key === 'signup');
    setErrorMessage(''); // Clear error messages on tab switch
  };

  const fetchAvailableRooms = async (checkInDate, checkOutDate) => {
    try {
      if (!checkInDate || !checkOutDate) {
        console.warn("Dates not selected yet");
        return;
      }

      const formattedCheckIn = format(new Date(checkInDate), "yyyy-MM-dd");
      const formattedCheckOut = format(new Date(checkOutDate), "yyyy-MM-dd");

      const response = await axios.get(
        // `https://api.codingboss.in/kovais/hotel/room-availability/?date_in=${formattedCheckIn}&date_out=${formattedCheckOut}`,
        `http://192.168.1.57:8000/kovais/hotel/room-availability/?date_in=${formattedCheckIn}&date_out=${formattedCheckOut}`,
        {
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
          },
        }
      );

      console.log("Fetched Available Rooms:", response.data.available_count);
      console.log("Total Rooms:", response.data.total_rooms)
      setRoom(response.data.total_rooms)
      setAvailableRooms(response.data.available_count);
    } catch (error) {
      console.error("Error fetching available rooms:", error);
    }
  };

  useEffect(() => {
    if (checkInDate && checkOutDate) {
      fetchAvailableRooms(checkInDate, checkOutDate);
    }
  }, [checkInDate, checkOutDate]);

  const handleShowModal = (room, index) => {
    if (!room) {
      console.error("Error: Room is undefined!");
      return;
    }

    let roomPrice = room.price;

    // If it's a string like "₹1,500", clean it
    if (typeof roomPrice === "string") {
      roomPrice = roomPrice.replace("₹", "").replace(/,/g, "");
    }

    const totalAmount = roomCounts[index] * parseFloat(roomPrice);

    setSelectedRoom({
      ...room,
      roomCount: roomCounts[index],
      guestCount: guestCounts[index],
      totalAmount: totalAmount,
    });

    setShowModal(true);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAadharFile(file);
      console.log("Selected file:", file.name);
    }
  };

  const handleSave = () => {
    if (!aadharFile) {
      alert("Please select an Aadhar file.");
      return;
    }

    // You can store it in state, localStorage, or show confirmation
    alert(`Aadhar file "${aadharFile.name}" saved successfully!`);

    // Optionally preview or show that upload was successful
    // setAadharUploaded(true); // You can conditionally hide the upload form
  };

  useEffect(() => {
    if (status && paytype) {
      setTimeout(() => {
        if (paytype === "offline") {
          handleFreeService();
        } else if (paytype === "online") {
          handlePayupi();
        }
      }, 500);
    }
  }, [status, paytype]);

  const handleUsePoints = (amount) => {
    const pointsToUse = parseInt(value);
    setUsedPoints(pointsToUse)

    // if (isNaN(pointsToUse) || pointsToUse <= 0) {
    //   alert("Enter a valid number of points.");
    //   return;
    // }

    // if (pointsToUse > points) {
    //   alert(`You only have ${points} points.`);
    //   return;
    // }

    // if (pointsToUse > selectedRoom.totalAmount) {
    //   alert(`You can't use more points than the price. Price is $${selectedRoom.totalAmount}.`);
    //   return;
    // }

    const newPoints = points - pointsToUse;
    const totalAmount = selectedRoom.totalAmount - pointsToUse;

    setPoints(newPoints);
    setTotalAmount(totalAmount);
    localStorage.setItem("signedUpUser", JSON.stringify(newPoints));
    localStorage.setItem("reducedPrice", JSON.stringify(totalAmount));

    // alert(`Used ${pointsToUse} points. New price: ${totalAmount}, Remaining points: ${points}`);
    setValue("");
  };

  const handleCheckIntoChange = (date) => {
    setCheckIn(date);
    setCheckInOpen(false); // Close the check-in calendar
    // Close check-in calendar
    // if (checkInRef.current) {
    //   checkInRef.current.setOpen(false);
    // }

    // Open check-out calendar
    if (checkOutRef.current) {
      checkOutRef.current.setFocus();
    }

    // Format date as yyyy-mm-dd
    const formattedDate = format(date, "yyyy-MM-dd"); // Or use: date.toISOString().split("T")[0]

    fetchAvailableRooms(formattedDate); setCheckOut(new Date(date.getTime() + 1 * 24 * 60 * 60 * 1000)); // Set checkout to next day
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const handleFreeService = () => {
    hotelRequest()
    setShowModal(false);

  }

  const handlePayupi = () => {
    setShowModal(false)
    hotelRequest()
    createPayment()
  }

  const hotelRequest = async () => {
    setLoading(true);
    const bookingPromises = [];
    const successBookings = [];
    const failedBookings = [];

    try {
      // Create individual bookings for each room
      for (let i = 0; i < selectedRoom.roomCount; i++) {
        const bookingData = {
          category: roomType,
          amount: Math.round((totalAmount || selectedRoom.totalAmount) / selectedRoom.roomCount),
          date_in: format(checkInDate, "yyyy-MM-dd"),
          date_out: format(checkOutDate, "yyyy-MM-dd"),
          payment_status: status,
          payment_type: paytype,
          room_count: selectedRoom.roomCount, // Each request is for 1 room
          guest_count: selectedRoom.guestCount,
          status: "booked",
          customer_id: user.user_id,
          guest_name: user.username,
          points: usedPoints ? Math.round(usedPoints / selectedRoom.roomCount) : 0,
          visit: purposeOfVisit
        };

        bookingPromises.push(
          axios.post(
            "http://192.168.1.57:8000/kovais/hotel/orders/",
            // "https://api.codingboss.in/kovais/hotel/orders/",
            bookingData,
            {
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
              },
            }
          )
            .then(response => {
              successBookings.push(response.data);
              localStorage.setItem("hotelId", JSON.stringify(response.data.order.id))
              console.log("Booking id:", response.data.order.id);
              return response;
            })
            .catch(error => {
              failedBookings.push({
                error: error.response?.data || error.message,
                attempt: i + 1
              });
              return null;
            })
        );
      }

      // Wait for all bookings to complete
      const results = await Promise.all(bookingPromises);

      // Update points only if all bookings succeeded
      if (failedBookings.length === 0 && usedPoints) {
        const newPoints = points - usedPoints;
        setPoints(newPoints);
        localStorage.setItem(`points_${user.user_id}`, JSON.stringify(newPoints));
      }

      // Show appropriate message based on results
      if (failedBookings.length === 0) {
        Swal.fire({
          title: "Booking Successful!",
          text: `${selectedRoom.roomCount} room(s) booked successfully.`,
          icon: "success",
          timer: 3000
        });
      } else if (successBookings.length > 0) {
        Swal.fire({
          title: "Partial Success",
          html: `
            <p>${successBookings.length} room(s) booked successfully.</p>
            ${failedBookings.length > 0 ?
              `<p>${failedBookings.length} room(s) failed to book.</p>` :
              ''
            }
          `,
          icon: "warning"
        });
      } else {
        throw new Error("All bookings failed");
      }

      // Close modals on success
      setShowModal(false);
      setShowLoginModal(false);
    } catch (error) {
      console.error("Booking Error:", error);
      Swal.fire({
        title: "Booking Failed",
        text: error.message || "An error occurred while processing your booking",
        icon: "error"
      });
    } finally {
      setLoading(false);
    }
  };


  const processBooking = async (paymentType) => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));

      setShowModal(false);
      alert(`Booking Confirmed!\nRoom: ${selectedRoom.title}\nTotal Paid: ₹${selectedRoom.totalAmount}`);
    } catch (error) {
      alert('Booking failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Filter and Sort Functions
  const getFilteredAndSortedRooms = () => {
    let filteredRooms = [...rooms];

    if (filterBy !== 'all') {
      filteredRooms = filteredRooms.filter(room => {
        switch (filterBy) {
          case 'eco': return room.ecoRating >= 4.0;
          case 'luxury': return room.price >= 5000;
          case 'business': return room.features.businessCenter;
          case 'instant': return room.instantConfirmation;
          default: return true;
        }
      });
    }

    filteredRooms.sort((a, b) => {
      switch (sortBy) {
        case 'price': return a.price - b.price;
        case 'rating': return b.rating - a.rating;
        case 'popularity': return b.popularityScore - a.popularityScore;
        case 'eco': return b.ecoRating - a.ecoRating;
        default: return 0;
      }
    });

    return filteredRooms;
  };

  const filteredRooms = getFilteredAndSortedRooms();



  useEffect(() => {
    const baseAmount = filteredRooms[0]?.price || 0;
    setTotalAmount(baseAmount * roomCounts[0] + (filteredRooms[0]?.taxes || 0));
  }, [roomCounts]);

  return (
    <div className={`search-results-container ${isDarkMode ? 'dark-mode' : ''}`}>
      {/* Search Form Header */}
      <div className="search-form-header">
        <div className="search-form-container">
          <div className="search-form-grid">
            <div className="form-field">
              <label className="form-label">Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="form-input"
              />
            </div>

            <div className="form-field date-field">
              <label className="form-label">Check-In Date</label>
              <div onClick={handleCheckInClick} className="date-input">
                <span>{checkInDate ? format(checkInDate, "yyyy-MM-dd") : "Not selected"}</span>
                <Calendar size={16} color="#dc3545" />
              </div>
            </div>

            <div className="form-field date-field">
              <label className="form-label">Check-Out Date</label>
              <div onClick={handleCheckOutClick} className="date-input">
                <span>{checkOutDate ? format(checkOutDate, "yyyy-MM-dd") : "Not selected"}</span>
                <Calendar size={16} color="#dc3545" />
              </div>
            </div>

            <div className="form-field">
              <label className="form-label">Room Type</label>
              <select
                value={roomType}
                onChange={(e) => setRoomType(e.target.value)}
                className="form-select"
              >
                <option value="Delux Room">Delux Room</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Calendar Components */}
      <DateCalendar
        isOpen={showCheckInCalendar}
        onClose={() => setShowCheckInCalendar(false)}
        onDateSelect={handleCheckInDateSelect}
        selectedDate={checkInDate}
        position="checkIn"
      />

      <DateCalendar
        isOpen={showCheckOutCalendar}
        onClose={() => setShowCheckOutCalendar(false)}
        onDateSelect={handleCheckOutDateSelect}
        selectedDate={checkOutDate}
        position="checkOut"
      />

      {/* Header */}
      <div className="main-header">
        <div className="header-container">
          <div className="header-content">
            <div className="header-info">
              <div className="location-info">
                <h1 className="location-title">
                  <MapPin size={28} color="#dc3545" />
                  Gobichettypalayam Hotels
                </h1>
                <p className="booking-details">
                  {checkInDate ? format(checkInDate, "yyyy-MM-dd") : "Not selected"} - {checkOutDate ? format(checkOutDate, "yyyy-MM-dd") : "Not selected"} • {guestCounts[0]} guests
                </p>
              </div>
              <span className="availability-badge">
                <Sparkles size={14} />
                {availableRooms} Available
              </span>
            </div>
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="theme-toggle-btn"
            >
              {isDarkMode ? <Sun size={16} /> : <Moon size={16} />}
            </button>
          </div>
        </div>
      </div>

      {/* Weather and Local Info Bar */}
      <div className="info-bar">
        <div className="info-bar-container">
          <div className="info-bar-content">
            <div className="info-items">
              <div className="weather-info">
                <Sun size={18} color="#dc3545" />
                <span>{weatherInfo.temperature} • {weatherInfo.condition}</span>
              </div>
              <div className="attractions-info">
                <MapPin size={16} color="#dc3545" />
                <span>{attractions.length} nearby attractions</span>
              </div>
            </div>
            <span className="last-updated">Last updated: 2 min ago</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {filteredRooms.map((room, index) => (
          <div key={room.id} className="room-card-enhanced">
            {/* Room Header */}
            <div className="room-header">
              <div className="room-header-content">
                <div className="room-header-info">
                  <h4 className="room-title">{room.title}</h4>
                  <div className="room-badges">
                    {room.instantConfirmation && (
                      <span className="badge instant-badge">Instant</span>
                    )}
                    {room.ecoRating >= 4.5 && (
                      <span className="badge eco-badge">Eco+</span>
                    )}
                    {realTimeOccupancy[room.id] && (
                      <span className="badge occupancy-badge">
                        <Eye size={12} />
                        {realTimeOccupancy[room.id]}% full
                      </span>
                    )}
                  </div>
                </div>
                <div className="room-actions">
                  <button
                    onClick={() => toggleSaveRoom(room.id)}
                    className={`action-btn ${savedRooms.has(room.id) ? 'saved' : ''}`}
                  >
                    <Heart size={16} fill={savedRooms.has(room.id) ? 'currentColor' : 'none'} />
                  </button>
                  <button
                    onClick={() => shareRoom(room)}
                    className="action-btn share-btn"
                  >
                    <Share2 size={16} />
                  </button>
                </div>
              </div>
            </div>

            <div className="room-content-grid">
              {/* Enhanced Image Gallery */}
              <div className="image-gallery-container">
                <div className="main-image-container">
                  <img
                    src={room.images[currentImageIndex[room.id] || 0]}
                    alt={room.title}
                    className="main-room-image"
                  />
                  <div className="image-counter">
                    {(currentImageIndex[room.id] || 0) + 1} / {room.images.length}
                  </div>
                  <button
                    onClick={() => handleVirtualTour(room)}
                    className="virtual-tour-btn"
                  >
                    <Camera size={14} />
                    360° Virtual Tour
                  </button>
                </div>
                <div className="thumbnail-gallery">
                  {room.images.map((img, imgIndex) => (
                    <img
                      key={imgIndex}
                      src={img}
                      alt={`${room.title} ${imgIndex + 1}`}
                      onClick={() => setCurrentImageIndex({
                        ...currentImageIndex,
                        [room.id]: imgIndex
                      })}
                      className={`thumbnail ${(currentImageIndex[room.id] || 0) === imgIndex ? 'active' : ''}`}
                    />
                  ))}
                </div>
              </div>

              {/* Enhanced Room Details */}
              <div className="room-details">
                {/* Rating and Reviews */}
                <div className="rating-section">
                  <div className="rating-info">
                    <div className="rating-badge">
                      <Star size={14} fill="currentColor" />
                      {room.rating}
                    </div>
                    <span className="review-count">({room.reviewCount} reviews)</span>
                    <span className="last-booked-badge">
                      <Clock size={12} />
                      Last booked: {room.lastBooked}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <p className="room-description">{room.description}</p>

                {/* Smart Amenities Grid */}
                <div className="amenities-section">
                  <h6 className="amenities-title">Premium Amenities</h6>
                  <div className="amenities-grid">
                    {room.amenities.slice(0, 6).map((amenity, amenityIndex) => (
                      <div
                        key={amenityIndex}
                        className={`amenity-item ${amenity.available ? 'available' : 'unavailable'}`}
                      >
                        <span className="amenity-icon">{amenity.icon}</span>
                        <span className="amenity-name">{amenity.name}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Eco Score and Sustainability */}
                <div className="sustainability-section">
                  <div className="sustainability-header">
                    <div className="eco-score">
                      <Award color="#dc3545" size={18} />
                      <span className="eco-score-text">Eco Score: {room.ecoRating}/5.0</span>
                    </div>
                    <span className="carbon-badge">{room.carbonFootprint}</span>
                  </div>
                  <div className="eco-progress-bar">
                    <div
                      className="eco-progress-fill"
                      style={{ width: `${(room.ecoRating / 5) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Pricing Section */}
                <div className="pricing-section">
                  <div className="price-display">
                    <span className="current-price">₹{room.price.toLocaleString()}</span>
                    <span className="original-price">₹{room.originalPrice.toLocaleString()}</span>
                    <span className="discount-badge">
                      {Math.round(((room.originalPrice - room.price) / room.originalPrice) * 100)}% OFF
                    </span>
                  </div>
                  <p className="tax-info">+ ₹{room.taxes} taxes & fees</p>
                </div>

                {/* Room and Guest Controls */}
                <div className="booking-controls">
                  <div className="control-grid">
                    {/* Rooms */}
                    <div className="control-group">
                      <label className="control-label">
                        Rooms <span className="availability-text">({availableRooms} available)</span>
                      </label>
                      <div className="counter-controls">
                        <button
                          onClick={() => decrementRoom(index)}
                          disabled={roomCounts[index] <= 1 || index !== 0}
                          className="counter-btn"
                        >
                          -
                        </button>
                        <span className="count-display">{roomCounts[index]}</span>
                        <button
                          onClick={() => incrementRoom(index)}
                          disabled={roomCounts[index] >= availableRooms || index !== 0}
                          className="counter-btn"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Guests */}
                    <div className="control-group">
                      <label className="control-label">Guests</label>
                      <div className="counter-controls">
                        <button
                          onClick={() => decrementGuest(index)}
                          disabled={guestCounts[index] <= 1 || index !== 0}
                          className="counter-btn"
                        >
                          -
                        </button>
                        <span className="count-display">{guestCounts[index]}</span>
                        <button
                          onClick={() => incrementGuest(index)}
                          disabled={guestCounts[index] >= roomCounts[index] * 3 || index !== 0}
                          className="counter-btn"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Total */}
                    <div className="total-display">
                      <div className="total-label">Total</div>
                      <div className="total-amount">
                        ₹{index === 0 ? totalAmount.toLocaleString() : room.price.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Special Request Section */}
                <div className="special-request-section">
                  <div className="special-request-card">
                    <div className="special-request-header" onClick={toggleAccordion}>
                      <div className="special-request-info">
                        <h4 className="special-request-title">Special Request</h4>
                        <p className="special-request-subtitle">
                          Special requests are subject to each hotel's availability, may be chargeable & can't be guaranteed.
                        </p>
                      </div>
                      <button className="accordion-toggle">
                        {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                      </button>
                    </div>

                    {isExpanded && (
                      <div className="special-request-content">
                        <p className="request-options-title">Commonly Requested</p>
                        <ul className="request-options-list">
                          {requestOptions.map(({ id, label, showTime, showInput }) => (
                            <li key={id} className="request-option-item">
                              <div className="checkbox-container">
                                <input
                                  type="checkbox"
                                  id={id}
                                  checked={!!selectedOptions[id]}
                                  onChange={() => handleCheckboxChange(id)}
                                  className="request-checkbox"
                                />
                                <label htmlFor={id} className="request-label">{label}</label>
                              </div>
                              {showTime && selectedOptions[id] && (
                                <div className="time-input-container">
                                  <label htmlFor={`${id}_time`} className="time-label">
                                    Select time:
                                  </label>
                                  <input
                                    type="time"
                                    id={`${id}_time`}
                                    value={selectedOptions[id]?.time || ""}
                                    onChange={(e) => handleTimeChange(id, e.target.value)}
                                    className="time-input"
                                  />
                                </div>
                              )}
                              {showInput && selectedOptions[id] && (
                                <div className="count-input-container">
                                  <label htmlFor={`${id}_count`} className="count-label">
                                    Enter number of beds:
                                  </label>
                                  <input
                                    type="number"
                                    id={`${id}_count`}
                                    min={1}
                                    value={selectedOptions[id]?.count || ""}
                                    onChange={(e) => handleCountChange(id, e.target.value)}
                                    placeholder="e.g. 1 or 2"
                                    className="count-input"
                                  />
                                </div>
                              )}
                            </li>
                          ))}
                        </ul>

                        <p className="other-request-title">Any other request?</p>
                        <textarea
                          cols="30"
                          rows="2"
                          placeholder="Enter your special request"
                          className="other-request-textarea"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="action-buttons">
                  <div className="action-buttons-grid">
                    <button
                      onClick={() => handleVirtualTour(room)}
                      className="action-btn-outline virtual-tour-action"
                    >
                      <Camera size={16} />
                      Virtual Tour
                    </button>
                    <button
                      onClick={() => setShowReviewModal(true)}
                      className="action-btn-outline reviews-action"
                    >
                      <MessageCircle size={16} />
                      Reviews
                    </button>
                    <button
                      onClick={() => verify(room, index)}
                      className="action-btn-primary book-now-action"
                    >
                      <Bookmark size={16} />
                      Book Now
                    </button>
                  </div>
                </div>

                {/* Special Offers */}
                {room.specialOffers && room.specialOffers.length > 0 && (
                  <div className="special-offers">
                    <h6 className="special-offers-title">Special Offers</h6>
                    <div className="special-offers-list">
                      {room.specialOffers.map((offer, offerIndex) => (
                        <span key={offerIndex} className="offer-badge">
                          {offer}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}

        {/* Nearby Attractions */}
        <div className="attractions-section">
          <h3 className="attractions-title">
            <Navigation color="#dc3545" />
            Explore Nearby
          </h3>
          <div className="attractions-grid">
            {attractions.map((attraction, index) => (
              <div key={index} className="attraction-card">
                <div className="attraction-icon">
                  {attraction.type === 'Historical' && '🏛️'}
                  {attraction.type === 'Shopping' && '🛍️'}
                  {attraction.type === 'Nature' && '🌳'}
                  {attraction.type === 'Culture' && '🎭'}
                </div>
                <h6 className="attraction-name">{attraction.name}</h6>
                <p className="attraction-distance">{attraction.distance}</p>
                <div className="attraction-rating">
                  <Star size={14} color="#dc3545" fill="currentColor" />
                  <span>{attraction.rating}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      <Modal
        show={showModal}
        onHide={() => setShowModal(false)}
        centered
        size="lg"
        className="booking-modal"
      >
        <Modal.Header closeButton className="border-bottom">
          <Modal.Title className="fw-bold d-flex align-items-center gap-2">
            <Sparkles color="#dc3545" /> Complete Your Booking
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {selectedRoom && (
            <>
              {/* Booking Summary */}
              <div className="booking-summary-section">
                <div className="row g-4">
                  <div className="col-md-8">
                    <h5 className="booking-room-title">{selectedRoom.title}</h5>
                    <p className="booking-room-description">{selectedRoom.description}</p>

                    <div className="booking-details-list">
                      <div className="booking-detail-item">
                        <Calendar size={16} color="#dc3545" />
                        <span>
                          {checkInDate instanceof Date
                            ? checkInDate.toLocaleDateString()
                            : checkInDate}{" "}
                          -{" "}
                          {checkOutDate instanceof Date
                            ? checkOutDate.toLocaleDateString()
                            : checkOutDate}
                        </span>
                      </div>
                      <div className="booking-detail-item">
                        <Users size={16} color="#dc3545" />
                        <span>
                          {selectedRoom.roomCount} room(s) •{" "}
                          {selectedRoom.guestCount} guest(s)
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="col-md-4 text-end">
                    <div className="booking-price-display">
                      ₹{selectedRoom.totalAmount?.toLocaleString() || selectedRoom.price.toLocaleString()}
                    </div>
                    <div className="booking-price-breakdown">
                      <div>Room: ₹{(selectedRoom.price * selectedRoom.roomCount).toLocaleString()}</div>
                      <div>Taxes: ₹{selectedRoom.taxes}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Purpose of Visit */}
              <div className="purpose-section">
                <label className="form-label fw-semibold">Purpose of Visit</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Business, Leisure, Family vacation..."
                  value={purposeOfVisit}
                  onChange={(e) => setPurposeOfVisit(e.target.value)}
                />
              </div>

              {/* Apply Points Section */}
              <div className="points-section">
                <Row className="align-items-center">
                  <Col md={8}>
                    <label htmlFor="points" className="form-label">
                      <b>Apply Points</b>
                    </label>
                    <input
                      id="points"
                      type="number"
                      placeholder="Enter points"
                      className="form-control"
                      value={value}
                      onChange={(e) => setValue(e.target.value)}
                    />
                  </Col>
                  <Col md={4}>
                    <Button
                      variant="info"
                      className="w-100 mt-4 mt-md-0"
                      onClick={() => handleUsePoints(totalAmount)}
                      disabled={!value || parseInt(value) <= 0}
                    >
                      Apply
                    </Button>
                  </Col>
                </Row>
              </div>

              {/* Payment Options */}
              <div className="payment-section">
                <h6 className="payment-title">
                  <Shield color="#dc3545" /> Secure Payment Options
                </h6>

                <div className="row g-3">
                  {/* Offline option */}
                  <div className="col-md-6">
                    <div
                      className="modern-payment offline-payment"
                      onClick={() => {
                        setStatus("pending");
                        setPaytype("offline");
                      }}
                    >
                      <div className="payment-icon">
                        <Clock color="#dc3545" size={24} />
                      </div>
                      <div className="payment-details">
                        <h6 className="payment-option-title">Reserve Now, Pay Later</h6>
                        <small className="payment-option-subtitle">
                          Secure your room with ₹0 upfront
                        </small>
                      </div>
                      <span className="payment-badge">Popular</span>
                    </div>
                  </div>

                  {/* Online option */}
                  <div className="col-md-6">
                    <div
                      className="modern-payment online-payment"
                      onClick={() => {
                        setStatus("paid");
                        setPaytype("online");
                      }}
                    >
                      <div className="payment-icon">
                        <Zap color="#dc3545" size={24} />
                      </div>
                      <div className="payment-details">
                        <h6 className="payment-option-title">Instant Confirmation</h6>
                        <small className="payment-option-subtitle">
                          Pay now and get instant booking
                        </small>
                      </div>
                      <span className="payment-badge">Instant</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Guarantees */}
              <div className="booking-guarantees">
                <div className="guarantee-item">
                  <Shield color="#dc3545" size={20} />
                  <div className="guarantee-text">Secure Booking</div>
                </div>
                <div className="guarantee-item">
                  <Clock color="#dc3545" size={20} />
                  <div className="guarantee-text">Free Cancellation</div>
                </div>
                <div className="guarantee-item">
                  <Award color="#dc3545" size={20} />
                  <div className="guarantee-text">Best Price Guarantee</div>
                </div>
              </div>
            </>
          )}
        </Modal.Body>
      </Modal>

      {/* Virtual Tour Modal */}
      {showVirtualTour && (
        <div className="virtual-tour-overlay">
          <div className="virtual-tour-modal">
            <div className="virtual-tour-header">
              <h3 className="virtual-tour-title">
                <Camera color="#dc3545" />
                360° Virtual Tour - {selectedRoom?.title}
              </h3>
              <button
                onClick={() => setShowVirtualTour(false)}
                className="virtual-tour-close"
              >
                ×
              </button>
            </div>
            <div className="virtual-tour-content">
              <div className="tour-viewer">
                <img
                  src={selectedRoom?.images[0]}
                  alt="Virtual Tour"
                  className="tour-image"
                />
                <div className="tour-controls">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="tour-control-btn"
                  >
                    {isPlaying ? <Pause size={16} /> : <Play size={16} />}
                  </button>
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="tour-control-btn"
                  >
                    {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                  </button>
                  <button className="tour-control-btn">
                    <Maximize size={16} />
                  </button>
                </div>
              </div>
              <div className="tour-progress">
                <div className="progress-bar">
                  <div
                    className="progress-fill"
                    style={{ width: `${virtualTourProgress}%` }}
                  />
                </div>
                <div className="progress-text">
                  <span>Tour Progress</span>
                  <span>{virtualTourProgress}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Login Modal */}
      <Modal
        show={showLoginModal}
        onHide={() => setShowLoginModal(false)}
        centered
      // className="auth-modal"
      >
        <Modal.Header closeButton className="border-0 pb-0">
          <Modal.Title className="w-100 text-center">Welcome</Modal.Title>
        </Modal.Header>
        <Modal.Body className="px-4 pt-0">
          <Tabs
            activeKey={isNewUser ? 'signup' : 'login'}
            onSelect={handleTabSelect}
            className="mb-4 nav-fill"
          >
            <Tab eventKey="login" title="Login" />
            <Tab eventKey="signup" title="Sign Up" />
          </Tabs>

          <Form>
            <Form.Group className="mb-3">
              <InputGroup>
                <InputGroup.Text className="bg-light">
                  <FaUser className="text-secondary" />
                </InputGroup.Text>
                <Form.Control
                  type="text"
                  value={userData.username || ""}
                  onChange={(e) => setUserData({ ...userData, username: e.target.value })}
                  placeholder="Username"
                />
              </InputGroup>
            </Form.Group>

            {isNewUser && (
              <Form.Group className="mb-3">
                <InputGroup>
                  <InputGroup.Text className="bg-light">
                    <FaEnvelope className="text-secondary" />
                  </InputGroup.Text>
                  <Form.Control
                    type="number"
                    value={userData.phone_number || ""}
                    onChange={(e) => setUserData({ ...userData, phone_number: e.target.value })}
                    placeholder="Enter Your Phone Number"
                  />
                </InputGroup>
              </Form.Group>
            )}

            <Form.Group className="mb-3">
              <InputGroup>
                <InputGroup.Text className="bg-light">
                  <FaLock className="text-secondary" />
                </InputGroup.Text>
                <Form.Control
                  type={showPassword ? "text" : "password"}
                  value={userData.password || ""}
                  onChange={(e) => setUserData({ ...userData, password: e.target.value })}
                  placeholder="Password"
                />
                <InputGroup.Text
                  className="bg-light cursor-pointer"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ?
                    <FaEyeSlash className="text-secondary" /> :
                    <FaEye className="text-secondary" />
                  }
                </InputGroup.Text>
              </InputGroup>
            </Form.Group>

            {errorMessage && (
              <div className="alert alert-danger py-2" role="alert">
                {errorMessage}
              </div>
            )}

            <Button
              variant="primary"
              onClick={isNewUser ? signup : loginUser}
              disabled={loading}
              className="w-100 py-2 mt-2 mb-3"
            >
              {loading ?
                <span>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  {isNewUser ? "Creating Account..." : "Logging in..."}
                </span> :
                isNewUser ? "Create Account" : "Login"
              }
            </Button>

            <div className="text-center mb-3">
              <p className="text-muted position-relative my-3">
                <span className="bg-white px-2 position-relative" style={{ zIndex: 1 }}>
                  Or continue with
                </span>
                <hr className="position-absolute top-50 start-0 end-0 m-0" style={{ zIndex: 0 }} />
              </p>
              <div className="d-flex justify-content-center gap-3">
                <Button variant="outline-secondary" className="rounded-circle p-2">
                  <FaGoogle />
                </Button>
                <Button variant="outline-secondary" className="rounded-circle p-2">
                  <FaFacebook />
                </Button>
              </div>
            </div>

            {isNewUser && (
              <p className="text-muted text-center small mt-4">
                By signing up, you agree to our <a href="#" className="text-decoration-none">Terms of Service</a> and <a href="#" className="text-decoration-none">Privacy Policy</a>.
              </p>
            )}
          </Form>
        </Modal.Body>
      </Modal>

      {/* Reviews Modal */}
      {showReviewModal && (
        <div className="reviews-overlay">
          <div className="reviews-modal">
            <div className="reviews-header">
              <h3>Guest Reviews & Ratings</h3>
              <button
                onClick={() => setShowReviewModal(false)}
                className="reviews-close"
              >
                ×
              </button>
            </div>
            <div className="reviews-content">
              {/* Overall Rating */}
              <div className="overall-rating-section">
                <div className="rating-display">
                  <div className="rating-circle">
                    <span className="rating-number">4.8</span>
                    <div className="rating-stars">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={8} fill="currentColor" />
                      ))}
                    </div>
                  </div>
                </div>
                <div className="rating-breakdown">
                  {[5, 4, 3, 2, 1].map(rating => (
                    <div key={rating} className="rating-row">
                      <span className="rating-label">{rating}</span>
                      <Star size={10} fill="currentColor" color="#dc3545" />
                      <div className="rating-bar">
                        <div
                          className="rating-bar-fill"
                          style={{ width: `${rating === 5 ? 75 : rating === 4 ? 20 : 5}%` }}
                        />
                      </div>
                      <span className="rating-count">
                        {rating === 5 ? '256' : rating === 4 ? '68' : '18'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Reviews */}
              <div className="reviews-list">
                <h6 className="reviews-list-title">Recent Reviews</h6>
                {[
                  {
                    name: "Sarah Johnson",
                    rating: 5,
                    date: "2 days ago",
                    comment: "Absolutely stunning room with amazing city views. The smart home features were impressive and the staff was incredibly helpful.",
                    helpful: 12
                  },
                  {
                    name: "Michael Chen",
                    rating: 4,
                    date: "1 week ago",
                    comment: "Great location and clean facilities. The eco-friendly initiatives are commendable. Would definitely stay again.",
                    helpful: 8
                  },
                  {
                    name: "Emma Davis",
                    rating: 5,
                    date: "2 weeks ago",
                    comment: "Perfect for business travel. The workspace was well-equipped and the WiFi was excellent throughout my stay.",
                    helpful: 15
                  }
                ].map((review, index) => (
                  <div key={index} className="review-item">
                    <div className="review-header">
                      <div className="reviewer-info">
                        <h6 className="reviewer-name">{review.name}</h6>
                        <div className="review-meta">
                          <div className="review-stars">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                size={12}
                                fill={i < review.rating ? "currentColor" : "none"}
                                color="#dc3545"
                              />
                            ))}
                          </div>
                          <span className="review-date">{review.date}</span>
                        </div>
                      </div>
                    </div>
                    <p className="review-text">{review.comment}</p>
                    <div className="review-actions">
                      <button className="helpful-btn">
                        <ThumbsUp size={10} />
                        Helpful ({review.helpful})
                      </button>
                      <button className="not-helpful-btn">
                        <ThumbsDown size={10} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="enhanced-footer">
        <Row className="text-center text-md-start py-4">
          <Col className="mb-3">
            <iframe
              src="https://www.google.com/maps?q=Kovais+Lodge+A%2FC+Rooms,+097,+SH+15,+Otthakkuthirai,+Gobichettipalayam,+Tamil+Nadu+638455&output=embed"
              width="100%"
              height="200"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="map-iframe"
            />
            <div className="footer-hotel-info">
              <h5><b>Kovais (AC) Hotel</b></h5>
              <p>097, SH 15, Otthakkuthirai, Tk, DT, Gobichettipalayam, Tamil Nadu 638455</p>
            </div>
          </Col>
        </Row>
        <p className="footer-copyright">&copy; 2024 KOVAIS. All Rights Reserved. | Contact: 9234567891 | Email: info@kovaisbeauty.com</p>
      </footer>
    </div>
  );
};
export default SearchResults;