import React, { useState, useEffect } from "react";
import { Card, Container, Button, Form, Row, Col } from "react-bootstrap";
import hotel from "./Image/hotl.jpg";
import gym from "./Image/Gym.jpg";
import saloon from "./Image/saloon.jpg";
import spa from "./Image/sp.jpg";
import axios from "axios";
import "./History.css";

const History = ({points, setPoints}) => {
  const [ratings, setRatings] = useState({});
  const [feedbacks, setFeedbacks] = useState({});
  const [id, setId] = useState(null);
  const [orders, setOrders] = useState([]);
  const [submittedFeedbacks, setSubmittedFeedbacks] = useState({});
  const [errorMessage, setErrorMessage] = useState("");
  

  const imageMap = {
    hotel: hotel,
    gym: gym,
    spa: spa,
    saloon: saloon,
  };


  useEffect(() => {
    const logginedUser = JSON.parse(localStorage.getItem("loggedInUser"));
    if (logginedUser && logginedUser.user_id) {
      setId(logginedUser.user_id);
    }

    // Load submitted feedbacks from localStorage
    const storedFeedbacks = JSON.parse(localStorage.getItem("submittedFeedbacks")) || {};
    const restoredRatings = {};
    const restoredComments = {};

    Object.keys(storedFeedbacks).forEach(orderId => {
      restoredRatings[orderId] = storedFeedbacks[orderId].rating;
      restoredComments[orderId] = storedFeedbacks[orderId].comment;
    });

    setSubmittedFeedbacks(Object.fromEntries(Object.keys(storedFeedbacks).map(id => [id, true])));
    setRatings(restoredRatings);
    setFeedbacks(restoredComments);
  }, []);

  useEffect(() => {
    if (!id) return;

    const fetchData = async () => {
      try {
        const response = await fetch(
          // `https://api.capture360.ai/kovais/orders/?user_id=${id}&status=completed`,
          `https://api.codingboss.in/kovais/orders/?user_id=${id}&status=completed`,

          {
            method: "get",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
            },
          }
        );

        if (!response.ok) throw new Error(`Failed to fetch orders: ${response.status}`);
        const data = await response.json();

        const allOrders = [
          ...data.hotel_orders.map((order) => ({
            ...order,
            guest_name: order.guest_name,
            service_type: "Deluxe Room (Ac)",
            serviceBy: "Veera",
            bookingDate: order.date_in,
            time: null,
            room_count: order.room_count,
            Category: "hotel",
            img: hotel,
            created_at: order.created_at,
          })),
          ...data.gym_orders.map((order) => ({
            ...order,
            guest_name: order.customer_name,
            service_type: order.plan,
            bookingDate: order.purchaseddate,
            time: order.timeslot,
            serviceBy: "Gokul",
            Category: "gym",
            img: gym,
            created_at: order.created_at,
          })),
          ...data.spa_orders.map((order) => ({
            ...order,
            guest_name: order.customer_name,
            service_type: order.services,
            bookingDate: order.date,
            time: order.time,
            serviceBy: "Guna",
            Category: "spa",
            img: spa,
            created_at: order.created_at,
          })),
          ...data.saloon_orders.map((order) => ({
            ...order,
            guest_name: order.customer_name,
            service_type: order.services,
            bookingDate: order.date,
            time: order.time,
            gender: order.category,
            serviceBy: "Anandh",
            Category: "saloon",
            img: saloon,
            created_at: order.created_at,
          })),
        ];

        setOrders(allOrders);
        const total = allOrders.reduce((acc, cur) => acc + (cur.points || 0), 0);
        setPoints(total);
      } catch (error) {
        console.error("Error fetching completed orders:", error);
      }
    };

    fetchData();
  }, [id]);

  const userPoints = async() =>{
    const userId =  JSON.stringify(localStorage.getItem("currentUserId"))
    try{
      // const response = await fetch (`https://api.capture360.ai/kovais/user-points/?user_id=${userId}`,
      const response = await fetch (`https://api.codingboss.in/kovais/user-points/?user_id=${userId}`,
    
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
        }
      );
      if (!response.ok) throw new Error(`Failed to fetch orders: ${response.status}`);
      const data = await response.json();
      console.log(data.points)
      setPoints(data.points)
      localStorage.setItem(`points_${data.user_id}`, JSON.stringify(data.points))
    }catch(errorMessage){
      console.error("Login Error:", error.response ? error.response.data : error.message);
      setErrorMessage(error.response?.data?.login || "Invalid credentials. Please try again.");
    }


   
  }

  const handleRatingChange = (orderId, selectedRating) => {
    setRatings((prevRatings) => ({
      ...prevRatings,
      [orderId]: selectedRating,
    }));
  };

  const handleFeedbackChange = (orderId, comment) => {
    setFeedbacks((prevFeedbacks) => ({
      ...prevFeedbacks,
      [orderId]: comment,
    }));
  };

  const handleFeedbackSubmit = async (e, orderId, order) => {
    e.preventDefault();
    const rating = ratings[orderId];
    const comment = feedbacks[orderId];

    if (!rating || !comment) {
      alert("Please give a rating and feedback before submitting.");
      return;
    }

    const payload = {
      customer_id: id,
      order_id: orderId,
      order_type: order.Category,
      rating,
      comment,
    };

    try {
      // await axios.post(`https://api.capture360.ai/kovais/${order_type}/orders/update/?customer_id=${customer_idid}&order_id=${orderId}`, payload, {
       await axios.post(`https://api.codingboss.in/kovais/${order_type}/orders/update/?customer_id=${customer_idid}&order_id=${orderId}`, payload, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      alert("Feedback submitted successfully!");

      // Save to localStorage
      const updated = {
        ...JSON.parse(localStorage.getItem("submittedFeedbacks") || "{}"),
        [orderId]: { rating, comment },
      };

      localStorage.setItem("submittedFeedbacks", JSON.stringify(updated));
      setSubmittedFeedbacks((prev) => ({
        ...prev,
        [orderId]: true,
      }));
    } catch (error) {
      console.error("Error submitting feedback:", error);
      alert("Failed to submit feedback.");
    }
  };

  return (
    <Container className="booking-history-container">
      <h2 className="heade text-center">Your Completed Orders</h2>
      <p className="text-center">Total Points: {points}</p>

      {orders.map((order) => (
        <Card key={order.id} className={`history-card ${order.Category}`}>
          <Row className="g-0">
            <Col md={6}>
              <Card.Body>
                <h4>{order.Category.charAt(0).toUpperCase() + order.Category.slice(1)}</h4>
                <p><strong>Name:</strong> {order.guest_name}</p>
                <p><strong>Service:</strong> {order.service_type}</p>
                <p><strong>Completed Date:</strong> {new Date(order.created_at).toLocaleDateString()}</p>
                <p><strong>Points Earned:</strong> 100</p>
                <p><strong>Serviced By:</strong> {order.serviceBy}</p>
                {order.Category === "saloon" && (
                  <p><strong>Gender:</strong> {order.gender}</p>
                )}

                <div className="star-rating">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span
                      key={star}
                      className={`star ${ratings[order.id] >= star ? "filled" : ""}`}
                      onClick={() => {
                        if (!submittedFeedbacks[order.id]) {
                          handleRatingChange(order.id, star);
                        }
                      }}
                      style={{
                        cursor: submittedFeedbacks[order.id] ? "default" : "pointer",
                        color: ratings[order.id] >= star ? "#ffc107" : "#ccc",
                        fontSize: "20px",
                      }}
                    >
                      ★
                    </span>
                  ))}
                </div>

                <Form onSubmit={(e) => handleFeedbackSubmit(e, order.id, order)}>
                  <Form.Group>
                    <Form.Label>Feedback:</Form.Label>
                    <Form.Control
                      as="textarea"
                      name="feedback"
                      value={feedbacks[order.id] || ""}
                      onChange={(e) => handleFeedbackChange(order.id, e.target.value)}
                      disabled={submittedFeedbacks[order.id]}
                      required
                    />
                  </Form.Group>
                  <Button
                    type="submit"
                    variant="success"
                    className="mt-2"
                    disabled={submittedFeedbacks[order.id]}
                  >
                    Submit Feedback
                  </Button>
                </Form>
              </Card.Body>
            </Col>
            <Col md={6}>
              <div className="image-container">
                <img src={order.img} alt={order.Category} className="order-image" />
              </div>
            </Col>
          </Row>
        </Card>
      ))}
    </Container>
  );
};

export default History;
